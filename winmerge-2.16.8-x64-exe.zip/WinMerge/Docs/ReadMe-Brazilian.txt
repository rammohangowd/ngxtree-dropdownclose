WINMERGE

WinMerge � um utilit�rio de compara��o e uni�o de arquivos com o c�digo fonte aberto o qual roda em todas as vers�es modernas do windows. Algumas fun��es requerem instala��es ou componentes adicionais. A �ltima vers�o do WinMerge e outras informa��es do WinMerge est�o dispon�veis em 
https://winmerge.org

 In�cio r�pido para o WinMerge: Leia o cap�tulo do in�cio r�pido do manual online para se iniciar com o WinMerge:
 https://manual.winmerge.org/QuickStart.html

 Manual em HTML: O manual est� dispon�vel online em 
https://manual.winmerge.org/ ele est� tamb�m possivelmente instalado (se escolhido assim) localmente e descarreg�vel separadamente de https://winmerge.org/ (veja a documenta��o) 

 Suporte a Scripts:
 Se voc� gostaria de trabalhar com scripts Voc� precisar� ter o Windows 
Scripting Host instalado. Se voc� receber quaisquer erros relacionados aos seus 
scripts por favor visite 
https://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
 para ter certeza que seu Scripting Host est� ambos atualizado e n�o corrompido. 

Suporte:
 Os desenvolvedores est�o respondendo as quest�es nos f�runs do WinMerge em Sourceforge.net:
https://sourceforge.net/forum/?group_id=13216
 
Bugs e pedidos para fun��es: 
Bugs e sugest�es para novas fun��es devem ser submetidos nos trackers dos bugs e pedidos para fun��es no sourceforge.net.
 
Bug tracker:
https://sourceforge.net/tracker/?group_id=13216&atid=113216 quando reportando um bug, por favor nos diga o n�mero da vers�o do WinMerge! As vers�es do 
WinMerge2.2.0 e posterior podem emitir um 'Log da Configura��o' no 
menu Ajuda/Configura��o. Por favor anexe esta info (como anexo do arquivo) ao relat�rio sobre o bug, ele tem muita informa��o �til para os desenvolvedores. 
Tracker 
RFE (pedido para fun��es):
 https://sourceforge.net/tracker/?group_id=13216&atid=363216


- Os Desenvolvedores do WinMerge
